package com.example.webapi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

        final String INSERT_DATA_URL = "http://11.0.247.167:82/Andro/insert.php";
    EditText name,email,password;
    Button submit,login;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    name= findViewById(R.id.edtName);
    email = findViewById(R.id.edtEmail);
    password = findViewById(R.id.edtPassword);

    submit = findViewById(R.id.btnSignUp);
    login = findViewById(R.id.btnLogin);

    login.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i = new Intent(MainActivity.this,Main2Activity.class);
            startActivity(i);
        }
    });

    submit.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            userSignUp(name.getText().toString(),email.getText().toString(),password.getText().toString());

        }
    });

    }



    public void userSignUp(final String userName, final String userEmail, final String userPassword){
        StringRequest stringRequest = new StringRequest(Request.Method.POST, INSERT_DATA_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if (response.trim().equals("done"))
                        { Toast.makeText(getApplicationContext(),"Record Added",Toast.LENGTH_LONG).show(); }
                        else if(response.trim().equals("failed")){
                            Toast.makeText(getApplicationContext(),"Record Not Added",Toast.LENGTH_LONG).show(); }
                        else
                        { Toast.makeText(getApplicationContext(),response,Toast.LENGTH_LONG).show(); }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_LONG).show(); }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> map = new HashMap<>();
                map.put("getName",userName);
                map.put("getEmail",userEmail);
                map.put("getPassword",userPassword);
                return map; }};
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

}
